﻿namespace Hotel_Managment
{
    partial class bookingpage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tname = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tmo = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tage = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ttp = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tacno = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.tr = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tad = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tta = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.trn = new System.Windows.Forms.TextBox();
            this.tcat = new System.Windows.Forms.TextBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tgst = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(518, 59);
            this.label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(243, 38);
            this.label7.TabIndex = 7;
            this.label7.Text = "Booking Room";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(731, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 25);
            this.label2.TabIndex = 10;
            this.label2.Text = "Catagory :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(731, 226);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 25);
            this.label3.TabIndex = 12;
            this.label3.Text = "Room No :";
            // 
            // tname
            // 
            this.tname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tname.Location = new System.Drawing.Point(303, 176);
            this.tname.Name = "tname";
            this.tname.Size = new System.Drawing.Size(198, 23);
            this.tname.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(194, 176);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 25);
            this.label4.TabIndex = 14;
            this.label4.Text = "Name :";
            // 
            // tmo
            // 
            this.tmo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tmo.Location = new System.Drawing.Point(301, 234);
            this.tmo.Name = "tmo";
            this.tmo.Size = new System.Drawing.Size(200, 23);
            this.tmo.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(153, 234);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(122, 25);
            this.label5.TabIndex = 16;
            this.label5.Text = "Mobile No :";
            // 
            // tage
            // 
            this.tage.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tage.Location = new System.Drawing.Point(301, 287);
            this.tage.Name = "tage";
            this.tage.Size = new System.Drawing.Size(200, 23);
            this.tage.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(211, 287);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 25);
            this.label6.TabIndex = 18;
            this.label6.Text = "Age :";
            // 
            // ttp
            // 
            this.ttp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ttp.Location = new System.Drawing.Point(870, 286);
            this.ttp.Name = "ttp";
            this.ttp.Size = new System.Drawing.Size(216, 23);
            this.ttp.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(725, 284);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(119, 25);
            this.label8.TabIndex = 20;
            this.label8.Text = "Total Per. :";
            // 
            // tacno
            // 
            this.tacno.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tacno.Location = new System.Drawing.Point(872, 339);
            this.tacno.Name = "tacno";
            this.tacno.Size = new System.Drawing.Size(214, 23);
            this.tacno.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(681, 339);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(163, 25);
            this.label9.TabIndex = 22;
            this.label9.Text = "AdharCard No :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(188, 346);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(87, 25);
            this.label10.TabIndex = 24;
            this.label10.Text = "Arrival :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(722, 400);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(122, 25);
            this.label11.TabIndex = 26;
            this.label11.Text = "CheckOut :";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(301, 348);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 30);
            this.dateTimePicker1.TabIndex = 8;
            // 
            // tr
            // 
            this.tr.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tr.Enabled = false;
            this.tr.Location = new System.Drawing.Point(301, 457);
            this.tr.Name = "tr";
            this.tr.Size = new System.Drawing.Size(200, 23);
            this.tr.TabIndex = 11;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(153, 455);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(126, 25);
            this.label12.TabIndex = 32;
            this.label12.Text = "Remaining :";
            // 
            // tad
            // 
            this.tad.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tad.Location = new System.Drawing.Point(301, 404);
            this.tad.Name = "tad";
            this.tad.Size = new System.Drawing.Size(200, 23);
            this.tad.TabIndex = 10;
            this.tad.TextChanged += new System.EventHandler(this.tad_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(159, 404);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(116, 25);
            this.label13.TabIndex = 30;
            this.label13.Text = "Advance  :";
            // 
            // tta
            // 
            this.tta.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tta.Enabled = false;
            this.tta.Location = new System.Drawing.Point(305, 500);
            this.tta.Name = "tta";
            this.tta.Size = new System.Drawing.Size(216, 23);
            this.tta.TabIndex = 12;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(128, 498);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(151, 25);
            this.label15.TabIndex = 34;
            this.label15.Text = "Total amount :";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(563, 598);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(123, 34);
            this.button1.TabIndex = 35;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // trn
            // 
            this.trn.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.trn.Location = new System.Drawing.Point(872, 229);
            this.trn.Name = "trn";
            this.trn.ReadOnly = true;
            this.trn.Size = new System.Drawing.Size(214, 23);
            this.trn.TabIndex = 37;
            // 
            // tcat
            // 
            this.tcat.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tcat.Location = new System.Drawing.Point(870, 176);
            this.tcat.Name = "tcat";
            this.tcat.ReadOnly = true;
            this.tcat.Size = new System.Drawing.Size(216, 23);
            this.tcat.TabIndex = 36;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(872, 400);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(214, 30);
            this.dateTimePicker2.TabIndex = 9;
            this.dateTimePicker2.ValueChanged += new System.EventHandler(this.dateTimePicker2_ValueChanged);
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Location = new System.Drawing.Point(875, 542);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(216, 23);
            this.textBox1.TabIndex = 38;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(709, 542);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 25);
            this.label1.TabIndex = 39;
            this.label1.Text = "Total Days :";
            // 
            // tgst
            // 
            this.tgst.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tgst.Enabled = false;
            this.tgst.Location = new System.Drawing.Point(872, 475);
            this.tgst.Name = "tgst";
            this.tgst.Size = new System.Drawing.Size(216, 23);
            this.tgst.TabIndex = 40;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(721, 473);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(119, 25);
            this.label14.TabIndex = 41;
            this.label14.Text = "GST 12% :";
            // 
            // bookingpage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(230)))), ((int)(((byte)(185)))));
            this.ClientSize = new System.Drawing.Size(1300, 703);
            this.Controls.Add(this.tgst);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.trn);
            this.Controls.Add(this.tcat);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tta);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.tr);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.tad);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.tacno);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.ttp);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.tage);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tmo);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tname);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label7);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "bookingpage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tname;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tmo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tage;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox ttp;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tacno;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox tr;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tad;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tta;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox trn;
        private System.Windows.Forms.TextBox tcat;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tgst;
        private System.Windows.Forms.Label label14;
    }
}